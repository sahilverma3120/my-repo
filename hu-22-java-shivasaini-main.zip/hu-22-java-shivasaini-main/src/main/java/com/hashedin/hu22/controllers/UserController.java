package com.hashedin.hu22.controllers;

import com.hashedin.hu22.entities.Cart;
import com.hashedin.hu22.entities.Course;
import com.hashedin.hu22.entities.RatingReview;
import com.hashedin.hu22.entities.User;
import com.hashedin.hu22.repositories.CourseRepository;
import com.hashedin.hu22.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@RestController
public class UserController {
    @Autowired
    UserRepository repository;
    @Autowired
    CourseRepository courseRepository;

    @RequestMapping(value = "/user/", method = RequestMethod.GET)
    public List<User> getUsers() {
        return repository.findAll();
    }

    @RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
    public User getUser(@PathVariable("id") int id) {
        return repository.findById(id).orElse(null);
    }

    @RequestMapping(value = "/user/", method = RequestMethod.POST)
    public User createUser(@RequestBody User user) {
        return repository.save(user);
    }

    @RequestMapping(value = "/user/", method = RequestMethod.PUT)
    public User updateUser(@RequestBody User product) {
        return repository.save(product);
    }

    @RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
    public void deleteUser(@PathVariable("id") int id) {
        repository.deleteById(id);
    }

    @RequestMapping(value = "user/{id}/cart", method = RequestMethod.GET)
    public Cart getCart(@PathVariable("id") int id) {
        return Objects.requireNonNull(repository.findById(id).orElse(null)).getCart();
    }

    @RequestMapping(value = "user/{id}/cart", method = RequestMethod.PUT)
    public Cart addCourse(@PathVariable("id") int id, @RequestParam int courseId) {
        Course course = courseRepository.findById(courseId).orElse(null);
        User user = getUser(id);
        user.getCart().getCartCourses().add(course);
        repository.save(user);
        return user.getCart();
    }

    @RequestMapping(value = "user/{id}/checkout", method = RequestMethod.GET)
    public User checkoutCourses(@PathVariable("id") int id) {
//        automatically crashes if already enrolled courses are checked out again
        User user = getUser(id);
        for (Course course : user.getCart().getCartCourses()) {
            course.setBoughtCount(course.getBoughtCount() + 1);
        }
        user.getEnrolledCourses().addAll(new ArrayList<>(user.getCart().getCartCourses()));
        user.getCart().getCartCourses().clear();
        return repository.save(user);
    }

    @RequestMapping(value = "user/{id}/enrolledCourses", method = RequestMethod.GET)
    public List<Course> getEnrolledCourses(@PathVariable("id") int id) {
        return getUser(id).getEnrolledCourses();
    }

    @RequestMapping(value = "user/{id}/enrolledCourses/{courseId}/rate", method = RequestMethod.POST)
    public Course rateCourse(@PathVariable("id") int id,
                             @PathVariable("courseId") int courseId,
                             @RequestBody RatingReview ratingReview) {
        Course course = courseRepository.findById(courseId).orElse(null);
        ratingReview.setUserId(id);
        if (course != null) {
            boolean found = false;
            for (RatingReview rr : course.getRatingReviews()) {
                if (rr.getUserId() == ratingReview.getUserId()) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                course.getRatingReviews().add(ratingReview);
                course.setAverageRating((course.getAverageRating() + ratingReview.getRating()) / 2);
            }
        }
        return courseRepository.save(course);
    }
}