package com.hashedin.hu22.controllers;

import com.hashedin.hu22.entities.Course;
import com.hashedin.hu22.repositories.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@RestController
public class CourseController {

    @Autowired
    CourseRepository repository;

    @RequestMapping(value = "/course/", method = RequestMethod.GET)
    public List<Course> getCourses(@RequestParam(required = false) String name,
                                   @RequestParam(required = false) String domain,
                                   @RequestParam(required = false, defaultValue = "") String order) {
        List<Course> list;
        if (name != null && domain != null)
            list = repository.findByNameDomainByOrderByPriceAsc(name, domain);
        else if (name != null)
            list = repository.findByName(name);
        else if (domain != null)
            list = repository.findByDomain(domain);
        else
            list = repository.findAll();

        if (order.equals("asc"))
            Collections.sort(list);
        else if (order.equals("desc"))
            Collections.sort(list, Collections.reverseOrder());
        return list;
    }

    @RequestMapping(value = "/course/{id}", method = RequestMethod.GET)
    public Course getCourse(@PathVariable("id") int id) {
        return repository.findById(id).orElse(null);
    }

    @RequestMapping(value = "/course/", method = RequestMethod.POST)
    public Course createCourse(@RequestBody Course course) {
        return repository.save(course);
    }

    @RequestMapping(value = "/course/", method = RequestMethod.PUT)
    public Course updateCourse(@RequestBody Course course) {
        return repository.save(course);
    }

    @RequestMapping(value = "/course/{id}", method = RequestMethod.DELETE)
    public void deleteCourse(@PathVariable("id") int id) {
        repository.deleteById(id);
    }

    @RequestMapping(value = "/sort/", method = RequestMethod.GET)
    public List<Course> getProduct() {
        return repository.findAll(Sort.by("Price"));
    }

    @RequestMapping(value = "/course/recommendations", method = RequestMethod.GET)
    public List<Course> getRecommendations(@RequestParam String[] domains,
                                           @RequestParam(required = false, defaultValue = "boughtCounter") String performanceSort) {
        if (performanceSort.equals("boughtCounter"))
            return repository.findByDomains(List.of(domains));
        else
            return repository.findByDomainsRatingSort(List.of(domains));
    }
}