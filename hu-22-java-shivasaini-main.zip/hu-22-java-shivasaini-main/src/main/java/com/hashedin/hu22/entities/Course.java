package com.hashedin.hu22.entities;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
public class Course implements Comparable<Course> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name = "";
    private String Domain = "";
    private String Description = "";
    private String Author = "";
    private int price = 0;
    private int duration = 0;
    private int boughtCount = 0;
    private float averageRating = 5;

    @OneToMany(cascade = CascadeType.ALL)
    private List<RatingReview> ratingReviews = List.of();

    @Override
    public int compareTo(Course course) {
        return Integer.compare(this.price, course.price);
    }
}