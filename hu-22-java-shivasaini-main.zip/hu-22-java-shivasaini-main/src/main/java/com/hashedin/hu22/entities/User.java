package com.hashedin.hu22.entities;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int user_id;
    private String name = "";
    private String first_name = "";
    private String last_name = "";
    private String bio = "";
    private String[] interests = new String[]{};
    private String type = "";
    private int experience = 0;
    private String expertise = "";
    private String profilePicture = "";

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id", referencedColumnName = "cart_id")
    private Cart cart = new Cart();

    @OneToMany(cascade = CascadeType.ALL)
    private List<Course> enrolledCourses = List.of();
}