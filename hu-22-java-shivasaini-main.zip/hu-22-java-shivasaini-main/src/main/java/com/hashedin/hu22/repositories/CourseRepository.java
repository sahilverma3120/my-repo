package com.hashedin.hu22.repositories;

import com.hashedin.hu22.entities.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


public interface CourseRepository extends JpaRepository<Course, Integer> {

    @Query(value = "SELECT * FROM course WHERE name=:name", nativeQuery = true)
    List<Course> findByName(@Param("name") String name);

    @Query(value = "SELECT * FROM course WHERE name=:name AND domain=:domain", nativeQuery = true)
    List<Course> findByNameDomainByOrderByPriceAsc(@Param("name") String name,
                                                   @Param("domain") String domain);

    @Query(value = "SELECT * FROM course WHERE domain=:domain", nativeQuery = true)
    List<Course> findByDomain(@Param("domain") String domain);

    @Query(value = "SELECT * FROM course WHERE domain IN :domains ORDER BY bought_count DESC", nativeQuery = true)
    List<Course> findByDomains(List<String> domains);

    @Query(value = "SELECT * FROM course WHERE domain IN :domains ORDER BY average_rating DESC", nativeQuery = true)
    List<Course> findByDomainsRatingSort(List<String> domains);
}
